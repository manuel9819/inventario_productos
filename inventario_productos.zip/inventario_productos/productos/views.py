from django.shortcuts import render, get_object_or_404,redirect
from django.contrib import messages
from django.views.generic import ListView, DeleteView
from django.urls import reverse_lazy
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
import json
from productos.models import Producto
from .serializers import ProductoSerializer
from rest_framework import generics



#Listar productos
class ProductoListAPIView(generics.ListAPIView):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer

#Eliminar productos
class ProductoDeleteAPIView(generics.DestroyAPIView):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer

class ProductoListView(ListView):
   model= Producto
   template_name = 'productos/producto_list.html'
   context_object_name = 'productos'


class DemoView(ListView):
    model = Producto
    template_name = 'productos/demo.html'
    context_object_name = 'productos'

class ProductoDeleteView(DeleteView):
    model = Producto
    template_name = 'productos/producto_confirm_delete.html'
    success_url = reverse_lazy('producto-list')
    context_object_name = 'producto'

    def delete (self, request, *args, **kwargs):
        Producto = self.get_object()
        messages.success(self.request, f'El producto "{Producto.nombre}" ha sido eliminado.')
        return super().delete(request, *args, **kwargs)


